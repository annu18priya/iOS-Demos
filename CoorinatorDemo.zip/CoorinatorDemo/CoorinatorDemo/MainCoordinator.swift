//
//  MainCoordinator.swift
//  CoorinatorDemo
//
//  Created by Annapurna Priya on 23/11/18.
//  Copyright © 2018 DigitasLBi. All rights reserved.
//

import Foundation
import UIKit

class MainCoordinator: Coordinator {
   
    var childCoordinators = [Coordinator]()
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let vc = ViewController.instantiate()
        vc.coordinator = self
        navigationController.pushViewController(vc, animated: false)
    }
    
    func moveToSecondVC() {
        let vc = SecondViewController.instantiateSecondSB()
        vc.coordinator = self
        navigationController.pushViewController(vc, animated: true)
    }
}
