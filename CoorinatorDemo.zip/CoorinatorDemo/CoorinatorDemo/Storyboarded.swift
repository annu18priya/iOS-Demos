//
//  Storyboarded.swift
//  CoorinatorDemo
//
//  Created by Annapurna Priya on 23/11/18.
//  Copyright © 2018 DigitasLBi. All rights reserved.
//

import Foundation
import UIKit

protocol Storyboarded {
    static func instantiate() -> Self
}

extension Storyboarded where Self: UIViewController {
    
    static func instantiate() -> Self {
        let fullname = NSStringFromClass(self)
        let classname = fullname.components(separatedBy: ".")[1]
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        return storyboard.instantiateViewController(withIdentifier: classname) as! Self
    }
    
    static func instantiateSecondSB() -> Self {
        let fullname = NSStringFromClass(self)
        let classname = fullname.components(separatedBy: ".")[1]
        let storyboard = UIStoryboard(name: "Second", bundle: Bundle.main)
        return storyboard.instantiateViewController(withIdentifier: classname) as! Self
    }
}
