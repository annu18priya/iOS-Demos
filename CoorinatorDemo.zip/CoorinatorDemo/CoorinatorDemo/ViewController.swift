//
//  ViewController.swift
//  CoorinatorDemo
//
//  Created by Annapurna Priya on 23/11/18.
//  Copyright © 2018 DigitasLBi. All rights reserved.
//

import UIKit

class ViewController: UIViewController, Storyboarded {
    
    weak var coordinator: MainCoordinator?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func secondTapped(sender: UIButton) {
        coordinator?.moveToSecondVC()
    }
}

