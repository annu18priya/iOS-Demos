//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by annapurna on 07/11/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var people = [Person]()
    var peopleDelete: NSManagedObjectContext!

    override func viewDidLoad() {
        super.viewDidLoad()

        peopleDelete = PersistenceService.persistentContainer.viewContext
        loadSaveData()
    }
    
    @IBAction func onPlusTapped(){
        tappedAlertShow()
    }
    
    func loadSaveData(){
        let fetchRequest: NSFetchRequest<Person> = Person.fetchRequest()
        
        do {
            let people = try PersistenceService.context.fetch(fetchRequest)
            self.people = people
            self.tableView.reloadData()
        } catch {}
    }
    
    func tappedAlertShow(){
        let alert = UIAlertController(title: "Add Person", message: nil, preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "Name"
        }
        
        alert.addTextField { (textField) in
            textField.placeholder = "Age"
            textField.keyboardType = .numberPad
        }
        
        let action = UIAlertAction(title: "Post", style: .default) { (_) in
            let name = alert.textFields!.first!.text!
            let age = alert.textFields!.last!.text!
            let person = Person(context: PersistenceService.context)
            person.name = name
            person.age = Int16(age)!
            PersistenceService.saveContext()
            self.people.append(person)
            self.tableView.reloadData()
        }
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
}

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.textLabel?.text = people[indexPath.row].name
        cell.detailTextLabel?.text = String(people[indexPath.row].age)
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete{
            peopleDelete.delete(people[indexPath.row])
        }
        do{
            try peopleDelete.save()
        }catch let error as NSError{
            print("Error While Deleting Note: \(error.userInfo)")
        }
        loadSaveData()
    }
}

extension ViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        let alert = UIAlertController(title: "Add Person", message: nil, preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "Name"
        }
        
        alert.addTextField { (textField) in
            textField.placeholder = "Age"
            textField.keyboardType = .numberPad
        }
        
        let action = UIAlertAction(title: "Post", style: .default) { (_) in
            let name = alert.textFields!.first!.text!
            let age = alert.textFields!.last!.text!

            self.peopleDelete = PersistenceService.persistentContainer.viewContext
            let fetchRequest: NSFetchRequest<Person> = Person.fetchRequest()
            
            do {
                
                let arrayPeopleGet = try self.peopleDelete.fetch(fetchRequest)
                let peopleUsers = arrayPeopleGet[indexPath.row]
                
                peopleUsers.setValue(name, forKey: "name")
                peopleUsers.setValue(Int16(age), forKey: "age")
                
                //save the context
                do {
                    try self.peopleDelete.save()
                    print("saved!")
                } catch let error as NSError  {
                    print("Could not save \(error), \(error.userInfo)")
                } catch {
                    
                }
                
            } catch {
                print("Error with request: \(error)")
            }
            
            self.tableView.reloadData()
        }
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
}

