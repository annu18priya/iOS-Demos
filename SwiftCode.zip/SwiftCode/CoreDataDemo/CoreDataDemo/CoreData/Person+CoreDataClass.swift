//
//  Person+CoreDataClass.swift
//  CoreDataDemo
//
//  Created by annapurna on 07/11/17.
//  Copyright © 2017 annapurna. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}

