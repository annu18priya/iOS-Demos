//: Playground - noun: a place where people can play

var bob = ["Hair Color":"Black","Height":"6ft 1","weight":"171","Eye Color":"Brown"]
var rob = ["Hair Color":"Brown","Height":"6ft 4","weight":"179","Eye Color":"Black"]
var hob = ["Hair Color":"Red","Height":"5ft 4","weight":"199","Eye Color":"Blue"]

struct Human{
    
    var numberOfLegs : Int
    var numberOfFingers : Int
    var name: String
    
    func sayName(){
        print(name)
    }
    
}

var dan = Human(numberOfLegs: 2, numberOfFingers: 5, name: "Avinash")
dan.name
dan.numberOfLegs
dan.numberOfFingers

var bobby = Human(numberOfLegs: 4, numberOfFingers: 10, name: "ABCDE")
bobby.name
bobby.numberOfLegs
bobby.numberOfFingers

dan.sayName()

//Example 2 finding value from Cubid(Box)

struct cubid{
    var widt:Double
    var height:Double
    var depth:Double
    
    var Volume:Double {
        return widt * height * depth
    }
    
}

var fourByFiveTwo = cubid(widt: 3, height: 2, depth: 5)
fourByFiveTwo.Volume

//Struct vs Class

class Hum{
    var numberOfLegs = 2
    var numberOfFinger = 10
    
    func introduceYourself(){
        print("I have 2 legs and 10 fingers")
    }
    
}

var Koren : Hum{
    var citezen = "Republic of korea"
    var homeTown = "Seoul"
}

let avinash = Koren()








