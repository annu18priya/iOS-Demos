//: Playground - noun: a place where people can play

//What is error handling - error handling is the process of responding to and recovering from error condition in your error program

//$1000 ->Error
// <0 --> Error(Minus)

var totalSpending = 0.0
enum spendingError:Error{
    case minus
    case limit
}

func calculateTotalSpening(morningSpending:Double , eveningSpending:Double) throws -> Double{
    if morningSpending < 0 || eveningSpending < 0{
        throw spendingError.minus
    }
    
    if(morningSpending + eveningSpending) > 1000 {
        throw spendingError.limit
    }
    
    return morningSpending + eveningSpending
}

do{
    try calculateTotalSpening(morningSpending: 300, eveningSpending: 500)
}catch spendingError.minus{
    print("How it is possible")
}catch spendingError.limit{
    print("You have reached the limit")
}