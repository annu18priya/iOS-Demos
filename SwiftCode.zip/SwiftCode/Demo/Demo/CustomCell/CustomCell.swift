//
//  CustomCell.swift
//  Demo
//
//  Created by annapurna on 10/28/17.
//  Copyright © 2017 com.annapurna.com. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var tblImg: UIImageView!
    @IBOutlet weak var tblLbl : UILabel!
    @IBOutlet weak var tblDetailLbl : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
