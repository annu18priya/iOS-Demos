//
//  SLogger.swift
//  Smartr
//
//  Created by Amit Saxena on 15/05/17.
//  Copyright © 2017 Appster. All rights reserved.
//

import UIKit
import XCGLogger

class SLogger: NSObject {
    private var logger:XCGLogger!
    static let sharedInstance : SLogger = {
        return SLogger()
    }()

    override init() {
        logger = XCGLogger()
        logger.setup(level: .debug, showLogIdentifier: false, showFunctionName: true, showThreadName: true, showLevel: true, showFileNames: true, showLineNumbers: true, showDate: true, writeToFile: "path/to/file", fileLevel: .debug)
    }
    
    func verbose(message:String)
    {
        logger.verbose(message)
    }
    
    func debug(message:String)
    {
        logger.debug(message)
    }
    
    func error(message:String)
    {
        logger.error(message)
    }
    
    func info(message:String)
    {
        logger.info(message)
    }
    
    func debugPrintInfo(any:Any)
    {
      debugPrint(any)
    }
}
