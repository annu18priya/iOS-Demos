//
//  GlobalUtility.swift
//  Smartr
//
//  Created by Amit Saxena on 25/01/17.
//  Copyright © 2017 Amit Saxena. All rights reserved.
//

import UIKit
import SDWebImage

class GlobalUtility: NSObject {


    class func loadImageWith(imgView: UIImageView, url: String?) {
       // imgView.sd_showActivityIndicatorView(true)
       // imgView.setIndicatorStyle(UIActivityIndicatorViewStyle.gray)

        if url != nil {
            imgView.sd_setImage(with: URL.init(string: url!), placeholderImage: nil, options: SDWebImageOptions.highPriority, completed: { (image: UIImage?, error: Error?, cacheType: SDImageCacheType, url: URL?) in
                imgView.image = image
            })
        }
    }
}

