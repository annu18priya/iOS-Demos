//
//  Constant.swift
//  Smartr
//

import UIKit
import Foundation


//MARK: helper methods
let APP_DELEGATE = UIApplication.shared.delegate as! AppDelegate
let SCREEN_SIZE  = UIScreen.main.bounds.size;
let SCREEN_RECT  = UIScreen.main.bounds;
let BASE_URL = ConfigurationManager.sharedManager().applicationEndPoint()
let DEVICE_UDID = UIDevice.current.identifierForVendor!.uuidString
let APP_VERSION = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
let DEVICE_TYPE = "iOS"


class Constant: NSObject {
    
    static let setOfEnv: Set<String> = [Constant.env.kDevelopment, Constant.env.kQA, Constant.env.kStaging, Constant.env.kProduction, Constant.env.kLocal]
    struct env{
        static let kDevelopment = "Development"
        static let kQA = "QA"
        static let kStaging = "Staging"
        static let kProduction = "Production"
        static let kLocal = "Local"
    }
    
    struct Nibs
    {
        // Declare your Custom cell nibs here
    }
    
    //MARK: APIServiceMethods
    struct APIServiceMethodsTableData {
        // Declare your api method here
        static let tableURL = Constant.APIServiceMethodsTableData.apiURL(methodName: "10/explicit.json")
        static func apiURL(methodName: String) -> String {
            return BASE_URL + methodName
        }
    }
    
}



//TableViewCell Constant


