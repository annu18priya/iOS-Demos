//
//  TableData+Services.swift
//  Demo
//
//  Created by annapurna on 10/28/17.
//  Copyright © 2017 com.annapurna.com. All rights reserved.
//

import Foundation
import SwiftyJSON


extension TableDataModel
{
    
    func callTableDataAPI(params:[String:Any], cntr:UIViewController, completionHandler:@escaping (_ weather:[TableDataModel]?, _ status:(stutusFlag:Bool, message:String)) -> Void)
    {
        cntr.view.endEditing(true);
        let apiUrl =  Constant.APIServiceMethodsTableData.tableURL
        HttpClient.sharedInstance.apiRequestCall(method: .get, apiURL: apiUrl, parameters: params, headers: HEADER) { (json:JSON?,error:NSError?) in
            if json !=  nil
            {
                if json != nil
                {
                    let user = TableDataModel().parseTableDataResponse(json: json!)
                    completionHandler(user, (stutusFlag: true, message: ""))
                    
                }
                else{
                    completionHandler(nil, (stutusFlag: false, message: ""))
                }
            }
            else{
                if error != nil{
                    completionHandler(nil, (stutusFlag: false, message: error!.localizedDescription))
                }
                else{
                    completionHandler(nil, (stutusFlag: false, message: "Some error occured"))
                }
            }
        }
    }
    
}
