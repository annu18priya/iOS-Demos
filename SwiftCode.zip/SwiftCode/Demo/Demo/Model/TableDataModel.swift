//
//  TableDataModel.swift
//  Demo
//
//  Created by annapurna on 10/28/17.
//  Copyright © 2017 com.annapurna.com. All rights reserved.
//

import UIKit
import SwiftyJSON

class TableDataModel: NSObject {

    var artistName: String = ""
    var artistCollectionName: String = ""
    var artistArtWorkURL: String = ""
    
    
    override init() {
        super.init();
    }
    
    
    func parseTableDataResponse(json:JSON) -> [TableDataModel]
    {
        var tableDataArray = [TableDataModel]()
        let feedDic = json["feed"].dictionary
        let resultsArray = feedDic?["results"]?.arrayValue
        for dicResult in resultsArray!
        {
          let objTblData = TableDataModel()
          objTblData.artistName = dicResult["artistName"].stringValue
          objTblData.artistCollectionName = dicResult["collectionName"].stringValue
          objTblData.artistArtWorkURL = dicResult["artworkUrl100"].stringValue
          tableDataArray.append(objTblData)
        }
        return tableDataArray
    }
    
}
