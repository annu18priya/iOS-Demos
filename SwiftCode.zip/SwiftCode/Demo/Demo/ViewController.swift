//
//  ViewController.swift
//  Demo
//
//  Created by annapurna on 10/28/17.
//  Copyright © 2017 com.annapurna.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tblViewDem : UITableView!

    var tblArray = [TableDataModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.callTblAPI()
    }
    
    // MARK:- API Call
    
    func callTblAPI()
    {
        let params = ["" : ""] as [String : Any]
        TableDataModel().callTableDataAPI(params: params, cntr: self) { (weather:[TableDataModel]?, status: (statusFlag: Bool, message: String)) in
            if status.statusFlag
            {
                self.tblArray = weather!
                SLogger.sharedInstance.debugPrintInfo(any: self.tblArray.count)
                self.tblViewDem.delegate = self
                self.tblViewDem.dataSource = self
                self.tblViewDem.reloadData()
                // Handle Success
                
            }
            else
            {
                // Handle Failure
            }
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController
{
    // MARK:- Table Methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.tblArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomCell
        
        let objTableData =  self.tblArray[indexPath.row]
        cell.tblLbl.text = objTableData.artistName
        cell.tblDetailLbl.text = objTableData.artistCollectionName
        GlobalUtility.loadImageWith(imgView: cell.tblImg, url:objTableData.artistArtWorkURL)

        
        return cell
    }
    
}


