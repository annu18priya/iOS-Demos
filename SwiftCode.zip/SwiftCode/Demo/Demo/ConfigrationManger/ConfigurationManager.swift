//
//  ConfigurationManager.swift
//


let kFacebookAppID = "10386972606934440"

import UIKit

final class ConfigurationManager: NSObject {
    
    /*
     Open your Project Build Settings and search for “Swift Compiler – Custom Flags” … “Other Swift Flags”.
     Add “-DDEVELOPMENT” to the Debug section
     Add “-DQA” to the QA section
     Add “-DSTAGING” to the Staging section
     Add “-DPRODUCTION” to the Release section
     */
    fileprivate enum AppEnvironment: String {
        case Development = "Development"
        case QA = "QA"
        case Staging = "Staging"
        case Production = "Release"
        case local = "Local"
        case temp = "Temp"
    }
    
    fileprivate struct AppConfiguration {
        var apiEndPoint: String
        var loggingEnabled: Bool
        
        var facebookID: String
        var analyticsKey: String
        var trackingEnabled: Bool
        
        fileprivate var environment: AppEnvironment
    }
    
    
    fileprivate var activeConfiguration: AppConfiguration!
    
    
    // MARK: - Singleton Instance
    private static let _sharedManager = ConfigurationManager()
    
    class func sharedManager() -> ConfigurationManager {
        return _sharedManager
    }
    
    private override init() {
        super.init()
        
        // Load application selected environment and its configuration
        if let environment = self.currentEnvironment() {
            
            self.activeConfiguration = self.configuration(environment: environment)
            
            if self.activeConfiguration == nil {
                assertionFailure(NSLocalizedString("Unable to load application configuration", comment: "Unable to load application configuration"))
            }
        } else {
            assertionFailure(NSLocalizedString("Unable to load application flags", comment: "Unable to load application flags"))
        }
    }
    
    private func currentEnvironment() -> AppEnvironment? {
        #if QA
            return AppEnvironment.QA
        #elseif STAGING
            return AppEnvironment.Staging
        #elseif PRODUCTION
            return AppEnvironment.Production
        #elseif Local
            return AppEnvironment.local
        #elseif Temp
            return AppEnvironment.temp
        #else // Default configuration DEVELOPMENT
            return AppEnvironment.Development
        #endif
    }
    
    /**
     Returns application active configuration
     
     - parameter environment: An application selected environment
     
     - returns: An application configuration structure based on selected environment
     */
    private func configuration(environment: AppEnvironment) -> AppConfiguration {
        
        switch environment {
        case .Development:
            return debugConfiguration()
        case .QA:
            return qaConfiguration()
        case .Staging:
            return stagingConfiguration()
        case .Production:
            return productionConfiguration()
        case .local:
            return localConfiguration()
        case .temp:
            return tempConfiguration()
            
        }
    }
    
    //TODO: Please change the key values
    private func debugConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: true,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: false,
                                environment: .Development)
    }
    
    //TODO: Please change the key values
    private func qaConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: true,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: false,
                                environment: .QA)
    }
    
    //TODO: Please change the key values
    private func stagingConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: true,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: true,
                                environment: .Staging)
    }
    
    //TODO: Please change the key values
    private func productionConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: false,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: true,
                                environment: .Production)
    }
    
    //TODO: Please change the key values
    private func localConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: false,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: true,
                                environment: .local)
    }
    
    //TODO: Please change the key values
    private func tempConfiguration() -> AppConfiguration {
        return AppConfiguration(apiEndPoint: "https://rss.itunes.apple.com/api/v1/us/apple-music/hot-tracks/all/",
                                loggingEnabled: false,
                                facebookID: kFacebookAppID,
                                analyticsKey: "",
                                trackingEnabled: true,
                                environment: .temp)
    }
}

extension ConfigurationManager {
    
    // MARK: - Public Methods
    
    func applicationEnvironment() -> String {
        return self.activeConfiguration.environment.rawValue
    }
    
    func applicationEndPoint() -> String {
        return self.activeConfiguration.apiEndPoint
    }
    
    func loggingEnabled() -> Bool {
        return self.activeConfiguration.loggingEnabled
    }
    
    func analyticsKey() -> String {
        return self.activeConfiguration.analyticsKey
    }
    
    func trackingEnabled() -> Bool {
        return self.activeConfiguration.trackingEnabled
    }
    
    // MARK: Facebook
    func facebookAppId() -> String
    {
        return self.activeConfiguration.facebookID
    }
    
    func currentSchemeConfiguration() -> String{
        #if QA
            return "QA"
        #elseif STAGING
            return "Staging"
        #elseif PRODUCTION
            return "Production"
        #elseif LOCAL
            return "Local"
        #elseif TEMP
            return "Temp"
        #else // Default configuration DEVELOPMENT
            return "Development"
        #endif
    }
    
}
