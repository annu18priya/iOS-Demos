

import Foundation
import UIKit
import Alamofire
import SwiftyJSON

let CONTENT_TYPE = "Content-Type"
let APP_JSON = "application/json";
let HEADER = [CONTENT_TYPE:APP_JSON]
let MIME_TYPE = "image/png"


class HttpClient: NSObject {
    
    static var sharedInstance : HttpClient = {
        return HttpClient()
    }()
    
    func apiRequestCall(method: HTTPMethod, apiURL:String,parameters:[String: Any],headers:[String:String], completionHandler: (@escaping (JSON?, NSError?) -> Void)) {
    
        var customHeader = headers
        //customHeader[KEY_TIME_ZONE] = "\(TimeZone.current.secondsFromGMT())"
       // customHeader[KEY_TIME_ZONE] = "\(TimeZone.current.identifier)"
        
        var encoding:ParameterEncoding = JSONEncoding.default;
        if method == .get
        {
            encoding = URLEncoding.default
        }
        Alamofire.request(apiURL, method: method, parameters: parameters, encoding: encoding, headers: customHeader)
            .responseJSON { response in
                print("\n\napi url >>>\(apiURL)")
                print("\n\napi params >>>\(parameters)")
                print("\n\napi header >>>\(customHeader)")
                print("\n\napi response.result.value >>> \(String(describing: response.result.value))")
                switch(response.result) {
                case .success(_):
                    if let data = response.result.value{
                        let json = JSON(data)
                        completionHandler(json, nil);
                        self.handleSessionExpiredForResponse(json: json)
                    }
                case .failure(_):
                    if response.result.error != nil{
                        print(response.result.error!)
                        completionHandler(nil, response.result.error as NSError?);
                    }
                }
        }
    }
    
    
    
    
    func serialize(_ value: Any) -> Data? {
        if JSONSerialization.isValidJSONObject(value) {
            return try? JSONSerialization.data(withJSONObject: value, options: [])
        }
        else {
            return String(describing: value).data(using: .utf8)
        }
    }
    
    func handleSessionExpiredForResponse(json:JSON)
    {
        
    }
    
}
