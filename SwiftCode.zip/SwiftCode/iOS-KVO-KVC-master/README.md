# KVO-KVC
This is a demo project for using kvo and kvc in iOS as a introduction of reactive programming

The full Youtube tutorial link is:
https://www.youtube.com/watch?v=xS7bvtGPiuU

This tutorial will give you the fundamental of reactive programming before we jump into the two most famous reactive programming SDK in iOS, which are 
RxSwift
https://github.com/ReactiveX/RxSwift
ReactiveCocoa
https://github.com/ReactiveCocoa/ReactiveCocoa

In this demo project, I will explain the basic concept of reactive and help you get ready for the RxSwift that I start teaching soon.

Please leave any comments and subscribe for the whole series.

Also follow my social account: 
Facebook: https://www.facebook.com/iosetutorial/
Twitter: https://twitter.com/sheldonwaaaaang 
Github: https://github.com/SheldonWangRJT

To donate to me, please use the following Paypal link:
https://www.paypal.com/us/cgi-bin/webscr?cmd=_flow&SESSION=3OPurxdLYJ5hDnhk2VwCG5IH3l3XkWA--xie554lWzKQKSSDIBXro5lf5v0&dispatch=5885d80a13c0db1f8e263663d3faee8d83a0bf7db316a7beb1b14b43acd04037&rapidsState=Donation__DonationFlow___StateDonationBilling&rapidsStateSignature=66e8cff0a1882cb53b44813529696734ec6f78f4
