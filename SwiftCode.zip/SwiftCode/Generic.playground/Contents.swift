//: Playground - noun: a place where people can play

//Generic Code is to write flixiable , reuseable functions and structurs

//Ex 

var stringArray = ["Hi","Hello","Bye"]
var intArray = [1,2,3,4,5]
var doubleArray = [1.12,2.1,3.2,4.3,5.2]

//print all the element

func printStringFromArray(a:[String]){
    for s in a{
        print(s)
    }
}

func printIntFromArray(a:[Int]){
    for i in a{
        print(i)
    }
}

func printDoubleFromArray(a:[Double]){
    for d in a {
        print(d)
    }
}

print(printStringFromArray(a: stringArray))
print(printIntFromArray(a: intArray))

//Print the element

func printElementFromArray<T>(a:[T]){
    for element in a{
        print(element)
    }
}

func printElementFromData<J>(s:[J]){
    for eElement in s{
        print(eElement)
    }
}

//Ex 2)



//Ex 3

var emptyArray = [String]()

struct GenericArray<T>{
    var items = [T]()
    
   mutating func push(item:T){
        items.append(item)
    }
}

var myFriendList = ["hey","Huy","Don"]

var array = GenericArray(items: myFriendList)
array.push(item: "Bob")
array.items
