//
//  ViewController.m
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import "ViewController.h"
#import "NSString+RemoveNums.h"
#import "UIColor+BackgroundColor.h"
#import "MYUtility.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //Create the string
    NSString *stringWithNums = @"ABC 123";
    NSLog(@"stringWithNums         --> %@",stringWithNums);
    
    //Run string through category method
    stringWithNums = [stringWithNums removeNumbersFromString:stringWithNums];
    //Output trimmed string to the console
    NSLog(@"trimmed stringWithNums --> %@",stringWithNums);
    self.view.backgroundColor = [UIColor changeBackgroundColor];
    
    NSString *reversed = [MYUtility reverse:stringWithNums];
    NSLog(@"%@",reversed);
    
    MYUtility *myUtitlty = [[MYUtility alloc]init];
    NSString *reverseStr = [myUtitlty stringToReverse:stringWithNums];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
