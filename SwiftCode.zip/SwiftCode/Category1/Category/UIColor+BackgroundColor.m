//
//  UIColor+BackgroundColor.m
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import "UIColor+BackgroundColor.h"

@implementation UIColor (BackgroundColor)

+(UIColor *)changeBackgroundColor{
    return [UIColor colorWithRed:73/255.0 green:202/255.0 blue:221/255.0 alpha:1.0];
}

@end
