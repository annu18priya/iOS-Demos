//
//  NSString+RemoveNums.m
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import "NSString+RemoveNums.h"

@implementation NSString (RemoveNums)

- (NSString *)removeNumbersFromString:(NSString *)string
{
    /*--
     - Implemetation logic for new category method
     * This category method creates a NSCharacterSet of 0-9
     * It trims any occurences of number characters from the input string
     * It returns the new string value to the receiver
     --*/
    
    NSString *trimmedString = nil;
    NSCharacterSet *numbersSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    trimmedString = [string stringByTrimmingCharactersInSet:numbersSet];
    return trimmedString;
}

@end
