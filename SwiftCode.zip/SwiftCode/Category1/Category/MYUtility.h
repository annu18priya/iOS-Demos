//
//  MYUtility.h
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MYUtility : NSObject

+(NSString *)reverse:(NSString *)stringToReverse;

-(NSString *)stringToReverse:(NSString *)string;

@end
