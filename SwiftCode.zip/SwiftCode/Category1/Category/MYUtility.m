//
//  MYUtility.m
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import "MYUtility.h"

@implementation MYUtility

+(NSString *)reverse:(NSString *)stringToReverse{
    NSString *trimmedString = nil;
    NSCharacterSet *numbersSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    trimmedString = [stringToReverse stringByTrimmingCharactersInSet:numbersSet];
    return trimmedString;
}

-(NSString *)stringToReverse:(NSString *)string{
    NSString *trimmedString = nil;
    NSCharacterSet *numbersSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    trimmedString = [string stringByTrimmingCharactersInSet:numbersSet];
    return trimmedString;
}

@end
