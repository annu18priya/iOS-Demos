//
//  NSString+RemoveNums.h
//  Category
//
//  Created by Avinash on 30/10/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (RemoveNums)

-(NSString *)removeNumbersFromString:(NSString *)string;

@end
