//
//  ViewController.swift
//  Lazy
//
//  Created by annapurna on 31/10/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let person = Person()
        person.name = "annapurna"
        person.isMale = true
        print(person.exerciseRoutine.exerciseFileName)
    }
    
    class ExerciseRoutine{
        var exerciseFileName = "exercise.html"
    }
    
    struct BodyStats{
        var height = 0
        var weight = 0
    }
    
    class Person {
        lazy var exerciseRoutine = ExerciseRoutine()
        var bodyStats = BodyStats()
        var name = ""
        var age = 0
        var isMale = false
    }
    
  

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

