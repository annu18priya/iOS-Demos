//: Playground - noun: a place where people can play

//Extension is to add new functionality to any thing

// Extensions includes the ability to extend types for which you do not have access to the original source code

// Ex 1

extension String{
    func sayHello(){
        print("Hello")
    }
}

var hello = "Hi"
hello.sayHello()

var erw = "Hi"
erw.sayHello()


//Ex - Square Value 

extension Int{
    var squared: Int{
        return(self * self)
    }
    
    func makeSquare() -> Int{
        return (self * self)
    }
}

var newInt = 30
newInt.squared

newInt.makeSquare()


// Extension for Class/Struct

class Bob{
    var nickName = "Bob The Developer"
}

var realBob = Bob()
realBob.nickName

extension Bob{
    func describeYourself() -> String{
        return "My Name is Bob and I go buy \(nickName)"
    }
}

var secondBob = Bob()
secondBob.nickName
secondBob.describeYourself()
