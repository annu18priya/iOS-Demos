//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Difference Between Struct is Class

//Struct can't be inhertated Class can be inheritated


//In Struct , it automatically allow you to input the value

struct myStruct{
    var someProperty:Double
}

var my = myStruct(someProperty: 50)
my.someProperty

//Class

class Circle{
    var x:Int
    var y:Int
    var radius:Double
    
    var diameter:Double{
        return radius * 2
    }
    
    init(x:Int,y:Int,radius:Double) {
        self.x = x
        self.y = y
        self.radius = radius
    }
}

var myCircle = Circle(x: 10, y: 10, radius: 20)
myCircle.diameter


struct square{
    var x1 : Int
    var x2 : Int
    var x3 : Int
    
    func getSquareData(){
        print(x1)
    }
}

var abc = square(x1: 10, x2: 20, x3: 30)
abc.x1

var getSquare = square(x1: 20, x2: 30, x3: 20)

getSquare.getSquareData()

