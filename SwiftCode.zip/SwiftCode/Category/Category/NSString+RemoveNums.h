//
//  NSString+RemoveNums.h
//  Category
//
//  Created by annapurna on 30/10/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (RemoveNums)

-(NSString *)removeNumbersFromString:(NSString *)string;

@end
