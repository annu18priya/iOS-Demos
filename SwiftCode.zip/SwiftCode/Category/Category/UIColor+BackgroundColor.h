//
//  UIColor+BackgroundColor.h
//  Category
//
//  Created by annapurna on 30/10/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (BackgroundColor)

+(UIColor *)changeBackgroundColor;

@end
