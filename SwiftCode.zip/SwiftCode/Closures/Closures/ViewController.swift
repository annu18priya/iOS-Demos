//
//  ViewController.swift
//  Closures
//
//  Created by Avinash on 02/11/17.
//  Copyright © 2017 Avinash. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var str = "Hello, playground"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Not Closure
        let result = sum(x: 5, y: 5)
        print(result)
        
        //Using Closure
        
       let sum1 =  sumUsingClosure(6,5)
       print(sum1)
        
    }
    
    //Function
    
    func sum(x: Int, y:Int) -> Int
    {
        return x + y
    }
    
    func hello() -> String{
        return "hello"
    }
    
    //Using Closure
    
    var sumUsingClosure:(Int, Int) -> (Int) = { x, y in
        return x + y
    }
    
    var helloWithClosure:() -> String = {
       return "Hello my name is hello"
    }
    
    
    // Memory Management Closures
    
    class HTMLElement{
        let name: String // Stored Property
        let text: String? // Stored Property
        
        // Lazy Property
        lazy var asHTML: () -> String = {
            if let text = self.text{
                return "<\(self.name)>\(text)</\(self.name)>"
            }else{
                return "<\(self.name)/>"
            }
        }
        
        init(name: String, text: String) {
            self.name = name
            self.text = text
        }
        
        deinit {
            print("\(name) is being deinitalized")
        }
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

