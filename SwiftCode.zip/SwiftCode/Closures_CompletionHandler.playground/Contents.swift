//: Playground - noun: a place where people can play

//Closures are self contained blocks of functionality that can be passed around and used in your code. Closures in swift are similar to block in C.

func thisNeedsToFinishBeforeWeCanDoTheNextStep(completion: () -> ()) {
    print("The quick brown fox")
    completion()
}
func thisFunctionNeedsToExecuteSecond() {
    print("jumped over the lazy dog")
}

thisNeedsToFinishBeforeWeCanDoTheNextStep { () -> () in
    
    thisFunctionNeedsToExecuteSecond()
    
}
