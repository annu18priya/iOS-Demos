//
//  ViewController.swift
//  GCD&NSOperation
//
//  Created by annapurna on 01/11/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //testPrintMethods()
        //queueTest1()
       // queueTest2()
       // queueTest3()
        //queueTest4()
       // queueTest5()
       // queueTest6()
       // queueTest7()
       // queueTest8()
      //  queueTest9()
        creatingDeadlock()
        //dispatchGroup()
    }
    
    
    //Dispatch Group
    func dispatchGroup()
    {
        
    }
    
    
    //Creating Deadlock
    
    func creatingDeadlock()
    {
        let q = DispatchQueue(label: " queue")
        print("1")
        q.async(execute: {() -> Void in
            print("2")
            q.async(execute: {() -> Void in
                print("3")
                print("6")
                print("7")
            })
            print("4")
        })
        print("5")
    }
    
    
    //Delaying the execution of a Queue
    func queueTest9(){
        let queue1 = DispatchQueue(label: "com.knowstack.queue1", qos:.utility, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        let queue2 = DispatchQueue(label: "com.knowstack.queue1", qos: .background, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        
        queue1.asyncAfter(deadline: .now()+5.0) {
            print("In Print Strawberries = \(Date())")
            self.printStrawberries()
            
        }
        
        queue2.async {
            print("In Print Balls = \(Date())")
            self.printBalls()
            
        }
    }
    
    
    //Utility is of higher priority than the background QoS
    
    func queueTest8(){
        let queue1 = DispatchQueue(label: "com.knowstack.queue1", qos:.utility, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        let queue2 = DispatchQueue(label: "com.knowstack.queue1", qos: .background, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        
        queue1.async {
            self.printStrawberries()
        }
        queue2.async {
            self.printBalls()
        }
        
    }
    
    
    func queueTest7(){
        let queue1 = DispatchQueue(label: "com.knowstack.queue1", qos: .userInteractive, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        let queue2 = DispatchQueue(label: "com.knowstack.queue1", qos: .utility, attributes: .concurrent, autoreleaseFrequency: .inherit, target: DispatchQueue.global())
        
        queue1.async {
            self.printStrawberries()
        }
        queue2.async {
            self.printBalls()
        }
        
    }
    
    //Below code runs the tasks on the main thread by using the main queue
    
    func queueTest6(){
        let mainQueue = DispatchQueue.main
        mainQueue.async {
            self.printApples()
        }
        
        mainQueue.async {
            self.printStrawberries()
        }
        mainQueue.async {
            self.printBalls()
        }
    }
    
    //Below code forces to run a task on the main thread on the global queue
    
    func queueTest5(){
        let globalQueue = DispatchQueue.global()
        globalQueue.sync {
            self.printApples()
        }
        globalQueue.async {
            self.printStrawberries()
        }
        globalQueue.async {
            self.printBalls()
        }
        
    }
    
    //Main Queue, Global Queue
    
    func queueTest4(){
        let globalQueue = DispatchQueue.global()
        globalQueue.async {
            self.printApples()
        }
        globalQueue.async {
            self.printStrawberries()
        }
        globalQueue.async {
            self.printBalls()
        }
        
    }
    
    //Using Dispatch Queue to run tasks on the main thread itself
    
    func queueTest3(){
        let queue1 = DispatchQueue(label: "com.knowstack.queue1")
        let queue2 = DispatchQueue(label: "com.knowstack.queue2")
        let queue3 = DispatchQueue(label: "com.knowstack.queue3")
        queue1.sync {
            self.printApples()
        }
        queue2.async {
            self.printStrawberries()
        }
        queue3.async {
            self.printBalls()
        }
    }
    
    //Using three Dispatch Queue to run 3 different tasks in a background thread
    func queueTest2(){
        let queue1 = DispatchQueue(label: "com.knowstack.queue1")
        let queue2 = DispatchQueue(label: "com.knowstack.queue2")
        let queue3 = DispatchQueue(label: "com.knowstack.queue3")
        queue1.async {
            self.printApples()
        }
        queue2.async {
            self.printStrawberries()
        }
        queue3.async {
            self.printBalls()
        }
        
    }
    
    //Using one Dispatch Queue to run 3 tasks in a background thread
    
    func queueTest1(){
        let queue = DispatchQueue(label: "com.knowstack.queue1")
        queue.async {
            self.printApples()
        }
        queue.async {
            self.printStrawberries()
        }
        queue.async {
            self.printBalls()
        }
        
    }
    
     //The below methods prints the thread on which they are being executed Main Thread or Background?
    
    func testPrintMethods(){
        printApples()
        printStrawberries()
        printBalls()
    }
    
    func printApples(){
        print("printApples is running on = \(Thread.isMainThread ? "Main Thread":"Background Thread")")
        for i in 0..<3{
            print("🍏\(i)")
        }
    }
    
    func printStrawberries(){
        print("printStrawberries is running on = \(Thread.isMainThread ? "Main Thread":"Background Thread")")
        for i in 0..<3{
            print("🍓\(i)")
        }
    }
    
    func printBalls(){
        print("printBalls is running on = \(Thread.isMainThread ? "Main Thread":"Background Thread")")
        for i in 0..<3{
            print("🎱\(i)")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

