//
//  ViewController.swift
//  StructAndClass
//
//  Created by annapurna on 02/11/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Struct -> Value Type
    // When you make a copy of a value type, it copies all the data from the thing you are copying into the new variable. They are 2 seperate things and changing one does not affect the other
    
    struct Person{
        var firstName:String = ""
        var lastName:String = ""
        
        public init(fName: String , lName: String){
            self.firstName = fName
            self.lastName = lName
        }
    }
    
    
    // class -> Reference Type
    // When you make a copy of a reference type, the new variable refers to the same memory location as the thing you are copying. This means that changing one will change the other since they both refer to the same memory location
    
    class Animal{
        var type:String = ""
        var color:String = ""
        
        public init(tType : String , CColor: String){
            self.type = tType
            self.color = CColor
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //----------------- Struct --------------//
        
        let p1 = Person.init(fName: "annapurna", lName: "Kumar")
        var p2 = p1
        p2.firstName = "Vishu"
        p2.lastName = "Dwivedi"
        
        print(p1.firstName)
        print(p1.lastName)
        
        print(p2.firstName)
        print(p2.lastName)
        
        //------------- Class Type ------------//
        
        let a1 = Animal.init(tType: "Lion", CColor: "Golden")
        let a2 = a1
        a2.type = "Dog"
        a2.color = "Black"
        
        print(a1.color)
        print(a1.type)
        
        print(a2.color)
        print(a2.type)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

