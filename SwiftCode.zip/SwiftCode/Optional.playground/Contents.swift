//: Playground - noun: a place where people can play

//Every Value has value
//Swift is type safe language

var newVar = 12345

//In Social Media

var myInfo = ["Name" : "Bob" , "Race": "Asin"]

myInfo["Profile Image"]

//Optional is to do with with an absence of value

var myName = "Bob"
//Optional

var myOptionalName: String? = "Bobby"

print(myName)
print(myOptionalName)

//You have to convert from ? to normal types --> Unrapping

//1 Force Unrapping / Implicit Unrapping()

var sentenct = myOptionalName!

var changedName = myName = sentenct
print(changedName)

//Unimplicit unwrapping -> Better and safar way

var nickName: String? = "Bobby the developer"
//Swift Syntax
if let myNicKName = nickName{
    print(myNicKName)
}






