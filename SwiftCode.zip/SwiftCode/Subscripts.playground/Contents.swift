//: Playground - noun: a place where people can play

//Subscript - Subscripts enable you to query instances of a type by writing one or more values in square brackets after the instance name. Their syntax is similar to both instance method syntax and computed property syntax. You write subscript definitions with the subscript keyword

//Ex 1 - Time Table

struct TimeTable{
    let multiplayer : Int
    subscript(index:Int) -> Int{
        return multiplayer * index
    }
}

let threeTimeTable = TimeTable(multiplayer: 3)
threeTimeTable[5]
threeTimeTable[2]
threeTimeTable[123]

//ShortCut of Week

class WeekDays{
    var days = ["Mon","Tue","Wed","Thurs","Fri"]
    subscript(index: Int) -> String{
        return days[index]
    }
}

var someWeek = WeekDays()
someWeek[1]


struct HealthInfo{
    //var info = ("Height" : 83, "Body Fat":12.5)
    var info = ("Height": 83, "Body Fat" : 12.5)
}

