//
//  ViewController.swift
//  ClosureDemo
//
//  Created by annapurna on 31/10/17.
//  Copyright © 2017 annapurna. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
 
        let states = ["California", "New York", "Texas", "Alaska"]
        
        let abbreviatedStates = states.map({ (state: String) -> String in
            let index = state.index(state.startIndex, offsetBy: 2)
            return state.substring(to: index).uppercased()
        })
        
        print(abbreviatedStates)
    
    }
   
    //Writing a function
    
   // func addTwoNumbers(number1:Int, number2:Int) -> {
     //   return number1 + number2
   // }
    

   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

